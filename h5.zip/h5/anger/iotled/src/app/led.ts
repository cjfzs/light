export class Device {
    id: string;
    status: number;
    customer_status: number
}