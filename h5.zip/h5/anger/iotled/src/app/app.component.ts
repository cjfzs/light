import { Component,OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Device } from './led';
import { LedsService } from './led.service'


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = '智能灯控';
  leds$:Observable<Device[]>;
  constructor(private ledService:LedsService){

  }
  ngOnInit(): void {
    this.leds$ = <Observable<Device[]>>
      this.ledService.getLeds();

  }
  
}
