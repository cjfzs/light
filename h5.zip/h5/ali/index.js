
// node引入包名
const iot = require('alibabacloud-iot-device-sdk');
//创建iot.device对象将会发起到阿里云IoT的连接
const device = iot.device({
    productKey: 'a1tNhNnvlZU', //将<productKey>修改为实际产品的ProductKey
    deviceName: 'led1',//将<deviceName>修改为实际设备的DeviceName
    deviceSecret: 'RAhIkoe4f85OjXQ5foQKYw01UMVFMot4',//将<deviceSecret>修改为实际设备的DeviceSecret
});
//监听connect事件
device.on('connect', () => {
    //将<productKey> <deviceName>修改为实际值
    device.subscribe('/a1tNhNnvlZU/led1/get');
    console.log('connect successfully!');
    device.publish('/a1tNhNnvlZU/led1/update', 'hello world!');
});
//监听message事件
device.on('message', (topic, payload) => {
    console.log(topic, payload.toString());
});